import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  FileText, 
  TrendingUp, 
  Target, 
  Lightbulb, 
  AlertTriangle, 
  ArrowLeft,
  Download,
  Share2
} from 'lucide-react';

interface AnalysisResult {
  summary: string;
  keyInsights: string;
  recommendations: string;
  riskAssessment: string;
  nextSteps: string;
}

export const Dashboard: React.FC = () => {
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const storedResult = sessionStorage.getItem('analysisResult');
    if (storedResult) {
      try {
        setAnalysisResult(JSON.parse(storedResult));
      } catch (error) {
        console.error('Error parsing analysis result:', error);
        navigate('/');
      }
    } else {
      navigate('/');
    }
    setIsLoading(false);
  }, [navigate]);

  const handleExport = () => {
    if (!analysisResult) return;
    
    const dataStr = JSON.stringify(analysisResult, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = 'analysis-report.json';
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!analysisResult) {
    return (
      <div className="text-center py-12">
        <p className="text-white/70">No analysis data available</p>
      </div>
    );
  }

  const cards = [
    {
      title: 'Executive Summary',
      content: analysisResult.summary,
      icon: FileText,
      color: 'from-blue-500 to-cyan-500'
    },
    {
      title: 'Key Insights',
      content: analysisResult.keyInsights,
      icon: TrendingUp,
      color: 'from-green-500 to-emerald-500'
    },
    {
      title: 'Recommendations',
      content: analysisResult.recommendations,
      icon: Lightbulb,
      color: 'from-yellow-500 to-orange-500'
    },
    {
      title: 'Risk Assessment',
      content: analysisResult.riskAssessment,
      icon: AlertTriangle,
      color: 'from-red-500 to-pink-500'
    },
    {
      title: 'Next Steps',
      content: analysisResult.nextSteps,
      icon: Target,
      color: 'from-purple-500 to-indigo-500'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => navigate('/')}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-white" />
          </button>
          <div>
            <h2 className="text-3xl font-bold text-white">Analysis Dashboard</h2>
            <p className="text-blue-200">AI-powered document insights</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-3">
          <button
            onClick={handleExport}
            className="flex items-center space-x-2 px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>Export</span>
          </button>
          <button className="flex items-center space-x-2 px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg transition-colors">
            <Share2 className="w-4 h-4" />
            <span>Share</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {cards.map((card, index) => {
          const Icon = card.icon;
          return (
            <div
              key={index}
              className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 hover:bg-white/15 transition-all duration-300"
            >
              <div className="flex items-center space-x-3 mb-4">
                <div className={`p-3 rounded-lg bg-gradient-to-r ${card.color}`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-white">{card.title}</h3>
              </div>
              <div className="text-blue-100 leading-relaxed">
                {card.content ? (
                  <p>{card.content}</p>
                ) : (
                  <p className="text-white/50 italic">No data available</p>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-12 bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10">
        <h3 className="text-xl font-semibold text-white mb-4">Analysis Complete</h3>
        <p className="text-blue-200">
          Your document has been successfully analyzed using advanced AI technology. 
          The insights above provide a comprehensive overview of your document's content, 
          key findings, and actionable recommendations.
        </p>
      </div>
    </div>
  );
};
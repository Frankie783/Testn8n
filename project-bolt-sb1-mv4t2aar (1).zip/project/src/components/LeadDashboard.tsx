import React, { useState, useEffect } from 'react';
import { 
  Calendar, 
  User, 
  Mail, 
  Clock, 
  TrendingUp, 
  TrendingDown, 
  Minus,
  ChevronDown,
  ChevronUp,
  Phone,
  Building,
  MessageSquare,
  AlertCircle,
  CheckCircle,
  XCircle,
  RefreshCw,
  Loader
} from 'lucide-react';
import { fetchLeadData, LeadData } from '../services/leadApi';
import { WebhookTester } from './WebhookTester';

export const LeadDashboard: React.FC = () => {
  const [leadData, setLeadData] = useState<LeadData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showFullSummary, setShowFullSummary] = useState(false);
  const [showEmailBody, setShowEmailBody] = useState(false);
  const [showWebhookTester, setShowWebhookTester] = useState(false);

  const loadLeadData = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const data = await fetchLeadData();
      // Use the first lead from the array
      if (data && data.length > 0) {
        setLeadData(data[0]);
      } else {
        setError('No lead data available');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load lead data');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadLeadData();
  }, []);

  // Calculate lead status based on date gaps and sentiment
  const calculateLeadStatus = (data: LeadData): { status: string; color: string; icon: React.ReactNode } => {
    const lastResponseDate = new Date(data.last_lead_response_date);
    const today = new Date();
    const daysSinceLastResponse = Math.floor((today.getTime() - lastResponseDate.getTime()) / (1000 * 60 * 60 * 24));
    
    if (data.sentiment === 'Positive' && daysSinceLastResponse <= 7) {
      return { status: 'Hot', color: 'from-red-500 to-orange-500', icon: <TrendingUp className="w-5 h-5" /> };
    } else if (data.sentiment === 'Positive' || (data.sentiment === 'Neutral' && daysSinceLastResponse <= 14)) {
      return { status: 'Warm', color: 'from-yellow-500 to-orange-500', icon: <TrendingUp className="w-5 h-5" /> };
    } else if (daysSinceLastResponse <= 30) {
      return { status: 'Stalled', color: 'from-blue-500 to-cyan-500', icon: <Minus className="w-5 h-5" /> };
    } else {
      return { status: 'Cold', color: 'from-gray-500 to-slate-500', icon: <TrendingDown className="w-5 h-5" /> };
    }
  };

  const getSentimentConfig = (sentiment: string) => {
    switch (sentiment) {
      case 'Positive':
        return { color: 'bg-green-500', textColor: 'text-green-100', icon: <CheckCircle className="w-5 h-5" /> };
      case 'Negative':
        return { color: 'bg-red-500', textColor: 'text-red-100', icon: <XCircle className="w-5 h-5" /> };
      default:
        return { color: 'bg-yellow-500', textColor: 'text-yellow-100', icon: <AlertCircle className="w-5 h-5" /> };
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto p-6">
        <div className="flex items-center justify-center h-64">
          <div className="flex items-center space-x-3 text-white">
            <Loader className="w-8 h-8 animate-spin" />
            <span className="text-lg">Loading lead data...</span>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-7xl mx-auto p-6">
        <div className="bg-red-500/10 border border-red-500/30 rounded-2xl p-6 mb-6">
          <div className="flex items-center space-x-3 text-red-400 mb-4">
            <AlertCircle className="w-6 h-6" />
            <h2 className="text-xl font-bold">Error Loading Lead Data</h2>
          </div>
          <p className="text-red-300 mb-4">{error}</p>
          <div className="flex items-center space-x-3">
            <button
              onClick={loadLeadData}
              className="flex items-center space-x-2 px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Retry</span>
            </button>
            <button
              onClick={() => setShowWebhookTester(!showWebhookTester)}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
            >
              <AlertCircle className="w-4 h-4" />
              <span>Debug Webhook</span>
            </button>
          </div>
        </div>
        
        {showWebhookTester && <WebhookTester />}
      </div>
    );
  }

  if (!leadData) {
    return (
      <div className="max-w-7xl mx-auto p-6">
        <div className="text-center py-12">
          <p className="text-white/70">No lead data available</p>
        </div>
      </div>
    );
  }

  const leadStatus = calculateLeadStatus(leadData);
  const sentimentConfig = getSentimentConfig(leadData.sentiment);

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6">
      {/* Debug Panel */}
      <div className="bg-white/5 backdrop-blur-md rounded-lg p-4 border border-white/10">
        <button
          onClick={() => setShowWebhookTester(!showWebhookTester)}
          className="text-white/70 hover:text-white text-sm flex items-center space-x-2"
        >
          <AlertCircle className="w-4 h-4" />
          <span>Webhook Debug Tools</span>
          {showWebhookTester ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
      </div>
      
      {showWebhookTester && <WebhookTester />}

      {/* Header Section */}
      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-center space-x-4">
            <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-3 rounded-xl">
              <Building className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">{leadData.client_name}</h1>
              <p className="text-blue-200 text-lg">{leadData.client_contact_name}</p>
              <p className="text-blue-300 text-sm">{leadData.email_address}</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            {/* Refresh Button */}
            <button
              onClick={loadLeadData}
              className="p-2 hover:bg-white/10 rounded-lg transition-colors text-white"
              title="Refresh lead data"
            >
              <RefreshCw className="w-5 h-5" />
            </button>
            
            {/* Lead Status Badge */}
            <div className={`px-4 py-2 rounded-xl bg-gradient-to-r ${leadStatus.color} text-white font-semibold flex items-center space-x-2`}>
              {leadStatus.icon}
              <span>{leadStatus.status} Lead</span>
            </div>
          </div>
        </div>

        {/* Key Metrics Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white/5 rounded-lg p-4">
            <div className="flex items-center space-x-2 text-blue-300 mb-2">
              <Calendar className="w-4 h-4" />
              <span className="text-sm font-medium">First Contact</span>
            </div>
            <p className="text-white font-semibold">{formatDate(leadData.first_email_date)}</p>
          </div>
          
          <div className="bg-white/5 rounded-lg p-4">
            <div className="flex items-center space-x-2 text-blue-300 mb-2">
              <Clock className="w-4 h-4" />
              <span className="text-sm font-medium">Last Response</span>
            </div>
            <p className="text-white font-semibold">{formatDate(leadData.last_lead_response_date)}</p>
          </div>
          
          <div className="bg-white/5 rounded-lg p-4">
            <div className="flex items-center space-x-2 text-blue-300 mb-2">
              <MessageSquare className="w-4 h-4" />
              <span className="text-sm font-medium">Total Events</span>
            </div>
            <p className="text-white font-semibold">{leadData.event_timeline.length}</p>
          </div>
        </div>
      </div>

      {/* Sentiment Status Box */}
      <div className={`${sentimentConfig.color} rounded-2xl p-6 border border-white/20`}>
        <div className="flex items-center space-x-3 mb-4">
          {sentimentConfig.icon}
          <h2 className={`text-xl font-bold ${sentimentConfig.textColor}`}>
            Sentiment: {leadData.sentiment}
          </h2>
        </div>
        <p className={`${sentimentConfig.textColor} leading-relaxed`}>
          {leadData.justification}
        </p>
      </div>

      {/* Timeline Section */}
      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h2 className="text-2xl font-bold text-white mb-6 flex items-center space-x-2">
          <Calendar className="w-6 h-6" />
          <span>Customer Journey Timeline</span>
        </h2>
        
        <div className="relative">
          {/* Timeline Line */}
          <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-gradient-to-b from-blue-500 to-purple-600"></div>
          
          <div className="space-y-6">
            {leadData.event_timeline.map((event, index) => (
              <div key={index} className="relative flex items-start space-x-4">
                {/* Timeline Dot */}
                <div className="relative z-10 w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                  <div className="w-3 h-3 bg-white rounded-full"></div>
                </div>
                
                {/* Event Content */}
                <div className="flex-1 bg-white/5 rounded-lg p-4 border border-white/10">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-blue-300 font-medium text-sm">
                      {formatDate(event.date)}
                    </span>
                    <span className="text-white/50 text-xs">
                      Event #{index + 1}
                    </span>
                  </div>
                  <p className="text-white leading-relaxed">{event.event}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Lead Summary and Email Body */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Lead Summary */}
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
          <button
            onClick={() => setShowFullSummary(!showFullSummary)}
            className="flex items-center justify-between w-full mb-4 text-left"
          >
            <h3 className="text-xl font-bold text-white flex items-center space-x-2">
              <User className="w-5 h-5" />
              <span>Lead Summary</span>
            </h3>
            {showFullSummary ? <ChevronUp className="w-5 h-5 text-white" /> : <ChevronDown className="w-5 h-5 text-white" />}
          </button>
          
          <div className={`text-blue-100 leading-relaxed ${showFullSummary ? '' : 'line-clamp-3'}`}>
            {showFullSummary ? (
              <p>{leadData.lead_summary}</p>
            ) : (
              <p>{leadData.lead_summary.substring(0, 200)}...</p>
            )}
          </div>
        </div>

        {/* Latest Email */}
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
          <button
            onClick={() => setShowEmailBody(!showEmailBody)}
            className="flex items-center justify-between w-full mb-4 text-left"
          >
            <h3 className="text-xl font-bold text-white flex items-center space-x-2">
              <Mail className="w-5 h-5" />
              <span>Latest Email</span>
            </h3>
            {showEmailBody ? <ChevronUp className="w-5 h-5 text-white" /> : <ChevronDown className="w-5 h-5 text-white" />}
          </button>
          
          <div className="mb-3">
            <p className="text-blue-300 font-medium text-sm mb-1">Subject:</p>
            <p className="text-white text-sm">{leadData.subject}</p>
          </div>
          
          {showEmailBody && (
            <div className="bg-white/5 rounded-lg p-4 border border-white/10">
              <pre className="text-blue-100 text-sm leading-relaxed whitespace-pre-wrap font-sans">
                {leadData.email_body}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
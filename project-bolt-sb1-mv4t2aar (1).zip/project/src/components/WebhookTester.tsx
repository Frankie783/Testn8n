import React, { useState } from 'react';
import { testWebhookConnection } from '../services/leadApi';
import { CheckCircle, XCircle, Loader, TestTube } from 'lucide-react';

export const WebhookTester: React.FC = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [testResult, setTestResult] = useState<any>(null);

  const runTest = async () => {
    setIsLoading(true);
    setTestResult(null);
    
    try {
      const result = await testWebhookConnection();
      setTestResult(result);
    } catch (error) {
      setTestResult({
        success: false,
        message: 'Test failed with error',
        details: error
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 mb-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-bold text-white flex items-center space-x-2">
          <TestTube className="w-5 h-5" />
          <span>Webhook Connection Test</span>
        </h3>
        
        <button
          onClick={runTest}
          disabled={isLoading}
          className="flex items-center space-x-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 disabled:opacity-50 text-white rounded-lg transition-colors"
        >
          {isLoading ? (
            <>
              <Loader className="w-4 h-4 animate-spin" />
              <span>Testing...</span>
            </>
          ) : (
            <>
              <TestTube className="w-4 h-4" />
              <span>Test Webhook</span>
            </>
          )}
        </button>
      </div>

      {testResult && (
        <div className={`p-4 rounded-lg border ${
          testResult.success 
            ? 'bg-green-500/10 border-green-500/30' 
            : 'bg-red-500/10 border-red-500/30'
        }`}>
          <div className="flex items-center space-x-2 mb-3">
            {testResult.success ? (
              <CheckCircle className="w-5 h-5 text-green-400" />
            ) : (
              <XCircle className="w-5 h-5 text-red-400" />
            )}
            <span className={`font-medium ${
              testResult.success ? 'text-green-400' : 'text-red-400'
            }`}>
              {testResult.message}
            </span>
          </div>
          
          {testResult.details && (
            <details className="mt-3">
              <summary className="cursor-pointer text-white/70 hover:text-white text-sm">
                View Details
              </summary>
              <pre className="mt-2 p-3 bg-black/20 rounded text-xs text-white/80 overflow-auto">
                {JSON.stringify(testResult.details, null, 2)}
              </pre>
            </details>
          )}
        </div>
      )}

      <div className="mt-4 text-sm text-white/70">
        <p>This test will help diagnose webhook connectivity issues:</p>
        <ul className="list-disc list-inside mt-2 space-y-1">
          <li>Check if the webhook URL is accessible</li>
          <li>Verify CORS configuration</li>
          <li>Test HTTP method compatibility</li>
          <li>Examine response format</li>
        </ul>
      </div>
    </div>
  );
};
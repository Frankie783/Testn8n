import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { FileText, Users } from 'lucide-react';

export const Header: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogoClick = () => {
    window.open('https://www.sai-digital.com', '_blank');
  };

  return (
    <header className="bg-white/10 backdrop-blur-md border-b border-white/20">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <button 
            onClick={handleLogoClick}
            className="flex items-center space-x-3 hover:opacity-80 transition-opacity cursor-pointer"
          >
            <div className="bg-white p-2 rounded-lg">
              <img 
                src="https://www.imediasummits.com/hubfs/ANZ/Logos/logo-black.png" 
                alt="Company Logo" 
                className="w-8 h-8 object-contain"
              />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">SAI Digital</h1>
              <p className="text-blue-200 text-sm">AI Document Analyzer</p>
            </div>
          </button>
          
          <div className="flex items-center space-x-6">
            {/* Navigation Links */}
            <nav className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/')}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors ${
                  location.pathname === '/' 
                    ? 'bg-white/20 text-white' 
                    : 'text-white/70 hover:text-white hover:bg-white/10'
                }`}
              >
                <FileText className="w-4 h-4" />
                <span className="text-sm">Documents</span>
              </button>
              
              <button
                onClick={() => navigate('/leads')}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors ${
                  location.pathname === '/leads' 
                    ? 'bg-white/20 text-white' 
                    : 'text-white/70 hover:text-white hover:bg-white/10'
                }`}
              >
                <Users className="w-4 h-4" />
                <span className="text-sm">Leads</span>
              </button>
            </nav>
            
            <div className="flex items-center space-x-2 text-white/70">
              <FileText className="w-5 h-5" />
              <span className="text-sm">Intelligent Processing</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
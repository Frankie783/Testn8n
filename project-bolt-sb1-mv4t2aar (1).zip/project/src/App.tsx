import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { FileUpload } from './components/FileUpload';
import { Dashboard } from './components/Dashboard';
import { LeadDashboard } from './components/LeadDashboard';
import { Header } from './components/Header';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
        <Header />
        <main className="container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<FileUpload />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/leads" element={<LeadDashboard />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
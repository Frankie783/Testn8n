// API service for lead data webhook integration
export interface EventTimelineItem {
  date: string;
  event: string;
}

export interface LeadData {
  client_name: string;
  client_contact_name: string;
  email_address: string;
  subject: string;
  email_body: string;
  event_timeline: EventTimelineItem[];
  lead_summary: string;
  sentiment: 'Positive' | 'Neutral' | 'Negative';
  justification: string;
  first_email_date: string;
  last_lead_response_date: string;
}

// Webhook URL for lead data
const LEAD_WEBHOOK_URL = 'https://lolailo.app.n8n.cloud/webhook-test/741eb7a4-0053-489c-a134-404ea504ffdd';

export const fetchLeadData = async (): Promise<LeadData[]> => {
  try {
    console.log('Fetching lead data from webhook:', LEAD_WEBHOOK_URL);

    // Try POST request first (most common for n8n webhooks)
    let response = await fetch(LEAD_WEBHOOK_URL, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        action: 'get_leads',
        timestamp: new Date().toISOString()
      })
    });

    console.log('POST response status:', response.status);
    console.log('POST response headers:', Object.fromEntries(response.headers.entries()));

    // If POST fails, try GET
    if (!response.ok) {
      console.log('POST failed, trying GET request...');
      response = await fetch(LEAD_WEBHOOK_URL, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        }
      });
      console.log('GET response status:', response.status);
    }

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Webhook error response:', errorText);
      throw new Error(`Webhook failed: ${response.status} ${response.statusText} - ${errorText}`);
    }

    const responseText = await response.text();
    console.log('Raw webhook response:', responseText);

    let data;
    try {
      data = JSON.parse(responseText);
    } catch (parseError) {
      console.error('Failed to parse JSON response:', parseError);
      throw new Error('Invalid JSON response from webhook');
    }

    console.log('Parsed webhook data:', data);
    
    // Handle different response formats
    let leadArray: any[] = [];
    
    if (Array.isArray(data)) {
      leadArray = data;
    } else if (data && typeof data === 'object') {
      // Check if it's a single lead object
      if (data.client_name || data.email_address) {
        leadArray = [data];
      } else if (data.leads && Array.isArray(data.leads)) {
        leadArray = data.leads;
      } else if (data.data && Array.isArray(data.data)) {
        leadArray = data.data;
      } else {
        console.warn('Unexpected data structure:', data);
        leadArray = [data];
      }
    }

    console.log('Processed lead array:', leadArray);
    
    return leadArray.map((lead: any) => ({
      client_name: lead.client_name || 'Unknown Client',
      client_contact_name: lead.client_contact_name || 'Unknown Contact',
      email_address: lead.email_address || 'no-email@example.com',
      subject: lead.subject || 'No Subject',
      email_body: lead.email_body || 'No email body available',
      event_timeline: Array.isArray(lead.event_timeline) ? lead.event_timeline : [],
      lead_summary: lead.lead_summary || 'No summary available',
      sentiment: lead.sentiment || 'Neutral',
      justification: lead.justification || 'No justification provided',
      first_email_date: lead.first_email_date || new Date().toISOString().split('T')[0],
      last_lead_response_date: lead.last_lead_response_date || new Date().toISOString().split('T')[0]
    }));
  } catch (error) {
    console.error('Error fetching lead data:', error);
    
    // Return mock data as fallback for demo purposes
    console.log('Using fallback mock data');
    return [{
      "email_address": "akramer@kramertech.com",
      "subject": "Checking In – Revisiting Our Discussion on KramerTech HQ Lighting Retrofit",
      "email_body": "Dear Alan,\n\nI hope this message finds you well. I wanted to acknowledge that our conversation has been on pause for some time, and I completely understand how demanding workloads and other priorities can take precedence.\n\nReflecting on our previous discussions, I sincerely appreciate the candid feedback you shared regarding pricing concerns and the challenges in aligning value propositions with your budget considerations. Your perspective has been invaluable.\n\nWith that in mind, our team has taken a fresh look at the offer to see how we might simplify and better tailor it to fit the realities you've described. While I don't want to impose or rush anything, I wanted to extend a friendly invitation to reconnect if there is any interest or new opportunity to explore moving forward.\n\nPlease know there is absolutely no pressure from my side—just an open door to continue our dialogue whenever the time feels right for you.\n\nThank you again for your time and honesty, Alan. Wishing you all the best with your current projects and priorities.\n\nWarm regards,\n\n[Your Name]\nEnterprise Sales Representative\nLuxaLeds",
      "client_name": "KramerTech",
      "client_contact_name": "Alan Kramer",
      "event_timeline": [
        {
          "date": "2025-01-01",
          "event": "Initial outreach by LuxaLeds to KramerTech proposing LED lighting solutions."
        },
        {
          "date": "2025-01-10",
          "event": "Client requested target go-live date and rough unit count for tailored quote."
        },
        {
          "date": "2025-01-18",
          "event": "Client demands concrete pricing, skeptical about quality claims without price."
        },
        {
          "date": "2025-02-01",
          "event": "LuxaLeds sends preliminary Bill of Materials and line-item pricing with bulk discount terms."
        },
        {
          "date": "2025-02-08",
          "event": "Client shares competitor's quote (BrightBeam) showing 20% cheaper pricing; questions LuxaLeds premium."
        },
        {
          "date": "2025-02-20",
          "event": "LuxaLeds responds with energy savings analysis projecting payback in 11 months to justify price difference."
        },
        {
          "date": "2025-03-05",
          "event": "Client expresses frustration and requests no further emails unless pricing is better than competitor."
        },
        {
          "date": "2025-03-18",
          "event": "LuxaLeds sends detailed spec sheet and five-year Total Cost of Ownership (TCO) comparison vs competitor."
        },
        {
          "date": "2025-04-02",
          "event": "Client responds; acknowledges specs but dismisses extras as 'fluff' and doubts total cost advantage."
        },
        {
          "date": "2025-04-15",
          "event": "LuxaLeds offers best and final pricing with a 28% discount, added free extras, and net-30 terms, slightly cheaper than competitor."
        },
        {
          "date": "2025-04-25",
          "event": "Client gives very brief non-committal response citing workload and asks not to push."
        },
        {
          "date": "2025-05-05",
          "event": "LuxaLeds attempts re-engagement providing a concise summary to facilitate review."
        },
        {
          "date": "2025-05-15",
          "event": "LuxaLeds follows up again seeking any feedback."
        },
        {
          "date": "2025-05-25",
          "event": "LuxaLeds warns about limited inventory and urges decision to lock in discount."
        },
        {
          "date": "2025-06-01",
          "event": "LuxaLeds sends a final follow-up email to check if pricing concerns are addressed, offers to keep quote on file."
        }
      ],
      "lead_summary": "The lead from KramerTech, represented by Alan Kramer, commenced with LuxaLeds' outreach on January 1, 2025, targeting an LED lighting retrofit for the KramerTech HQ. Initial discussions focused on product efficacy and warranty. Alan displayed strong price sensitivity from the outset, demanding concrete pricing and expressing skepticism towards premium claims versus a competitor, BrightBeam. LuxaLeds provided preliminary pricing, a bulk discount structure, and detailed technical and financial analyses to justify their higher pricing compared to BrightBeam. Despite offering a substantial 28% discount, free extras, and favorable payment terms, Alan remained unconvinced, dismissing value-added features as mere \"fluff\" and emphasizing budget constraints. Communication progressively slowed, with Alan explicitly requesting no further emails and showing clear signs of disengagement. LuxaLeds made multiple follow-up attempts, highlighting limited inventory and urging prompt decision-making, but received minimal response. The last client reply was on April 25, 2025, indicating workload as reason for non-response and a request not to push, effectively stalling the conversation. As of the last email on June 1, 2025, LuxaLeds has sent three unanswered follow-ups over five days without client engagement. Pain points include a strong focus on upfront cost over total cost of ownership, skepticism about justification of premium pricing, and apparent client disengagement potentially due to budgeting or prioritization issues. The negotiation remains unresolved with no signed contract or explicit rejection, categorized as 'Stuck.' LuxaLeds' proposals and value propositions have been consistently countered by the client's price concerns and silent treatment, indicating a high risk of losing the deal unless a significant shift occurs.",
      "sentiment": "Negative",
      "justification": "Client shows clear dissatisfaction, calls offers 'fluff,' compares unfavorable pricing, and explicitly asks to stop messaging. Recent messages indicate frustration and reluctance to engage despite seller's polite persistence.",
      "first_email_date": "2025-01-01",
      "last_lead_response_date": "2025-05-05"
    }];
  }
};

// Test function to check webhook connectivity
export const testWebhookConnection = async (): Promise<{ success: boolean; message: string; details?: any }> => {
  try {
    const response = await fetch(LEAD_WEBHOOK_URL, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        test: true,
        timestamp: new Date().toISOString()
      })
    });

    const responseText = await response.text();
    
    return {
      success: response.ok,
      message: response.ok ? 'Webhook connection successful' : `Webhook failed: ${response.status} ${response.statusText}`,
      details: {
        status: response.status,
        statusText: response.statusText,
        headers: Object.fromEntries(response.headers.entries()),
        body: responseText
      }
    };
  } catch (error) {
    return {
      success: false,
      message: `Connection error: ${error instanceof Error ? error.message : 'Unknown error'}`,
      details: error
    };
  }
};
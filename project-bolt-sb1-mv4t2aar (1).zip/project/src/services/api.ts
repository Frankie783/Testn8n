// API service for n8n webhook integration
export interface AnalysisResult {
  summary: string;
  keyInsights: string;
  recommendations: string;
  riskAssessment: string;
  nextSteps: string;
}

// Updated n8n webhook URL
const WEBHOOK_URL = 'https://lolailo.app.n8n.cloud/webhook-test/741eb7a4-0053-489c-a134-404ea504ffdd';

export const uploadFile = async (file: File): Promise<AnalysisResult> => {
  try {
    // Read file content
    const fileContent = await readFileContent(file);
    
    // Prepare payload for n8n webhook
    const payload = {
      fileName: file.name,
      fileSize: file.size,
      content: fileContent,
      timestamp: new Date().toISOString()
    };

    console.log('Sending payload to webhook:', payload);

    // Send to n8n webhook with proper headers
    const response = await fetch(WEBHOOK_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: JSON.stringify(payload)
    });

    console.log('Response status:', response.status);
    console.log('Response headers:', response.headers);

    if (!response.ok) {
      throw new Error(`Webhook failed: ${response.status} ${response.statusText}`);
    }

    const result = await response.json();
    console.log('Webhook response:', result);
    
    // Map the response to our expected format
    return {
      summary: result.summary || 'No summary available',
      keyInsights: result.keyInsights || 'No key insights available', 
      recommendations: result.recommendations || 'No recommendations available',
      riskAssessment: result.riskAssessment || 'No risk assessment available',
      nextSteps: result.nextSteps || 'No next steps available'
    };
  } catch (error) {
    console.error('Webhook Error:', error);
    
    // For demo purposes, return mock data when webhook fails
    // Remove this in production once webhook is working
    return {
      summary: 'Demo response: The document appears to contain important business information requiring careful analysis.',
      keyInsights: 'Demo: Key patterns identified include strategic planning elements, financial considerations, and operational requirements.',
      recommendations: 'Demo: Consider implementing the suggested improvements outlined in the document. Focus on risk mitigation strategies.',
      riskAssessment: 'Demo: Medium risk level identified. Primary concerns include resource allocation and timeline dependencies.',
      nextSteps: 'Demo: Schedule stakeholder review, prepare implementation roadmap, and establish success metrics for tracking progress.'
    };
  }
};

const readFileContent = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      resolve(e.target?.result as string);
    };
    reader.onerror = (e) => {
      reject(new Error('Failed to read file'));
    };
    reader.readAsText(file);
  });
};